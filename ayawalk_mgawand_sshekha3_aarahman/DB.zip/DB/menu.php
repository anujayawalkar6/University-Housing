<div id="leftmenu"><img src="images/left-bar.png" alt="Site Menu" /></div>
